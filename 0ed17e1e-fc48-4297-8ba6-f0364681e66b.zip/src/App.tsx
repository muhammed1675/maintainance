import React, { useState } from 'react';
import { motion } from 'framer-motion';
import {
  CheckIcon,
  CircleCheckIcon,
  HardHatIcon,
  Loader2Icon,
  MailIcon,
  DoorOpenIcon,
  PackageIcon,
  WrenchIcon } from
'lucide-react';
type StepState = 'done' | 'active' | 'next';
const steps: {
  num: string;
  title: string;
  desc: string;
  state: StepState;
  icon: React.ElementType;
}[] = [
{
  num: '01',
  title: 'Taking listings offline',
  desc: 'All hostels safely archived',
  state: 'done',
  icon: PackageIcon
},
{
  num: '02',
  title: 'Rebuilding the platform',
  desc: 'New filters & faster bookings',
  state: 'active',
  icon: WrenchIcon
},
{
  num: '03',
  title: 'Reopening doors',
  desc: 'Back online for LAUTECH students',
  state: 'next',
  icon: DoorOpenIcon
}];

const fadeUp = {
  hidden: {
    opacity: 0,
    y: 18
  },
  show: (i: number) => ({
    opacity: 1,
    y: 0,
    transition: {
      delay: 0.08 * i,
      duration: 0.45,
      ease: [0.21, 0.61, 0.35, 1]
    }
  })
};
export function App() {
  const [email, setEmail] = useState('');
  const [submitted, setSubmitted] = useState(false);
  const [error, setError] = useState(false);
  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)) {
      setError(true);
      return;
    }
    setError(false);
    setSubmitted(true);
  };
  return (
    <div className="relative flex min-h-screen w-full flex-col overflow-x-hidden bg-[#f8fafc] text-[#0f172a]">
      {/* Logo watermark in the background — subtle, barely showing */}
      <div
        aria-hidden="true"
        className="pointer-events-none fixed inset-0 z-0 flex items-center justify-center">
        
        <img
          src="https://lautech-rentals.vercel.app/rentora-logo.png"
          alt=""
          className="w-[70%] max-w-[680px] opacity-[0.035] grayscale" />
        
      </div>

      {/* Subtle caution-tape motif at the very bottom edge */}
      <div
        aria-hidden="true"
        className="rentora-caution pointer-events-none fixed -bottom-[70px] -right-[20%] z-0 h-[130px] w-[150%] -rotate-6 opacity-[0.05]" />
      

      <div className="relative z-10 flex min-h-screen flex-col">
        {/* Header — white navbar like the homepage */}
        <header className="w-full border-b border-[#e8eaf0] bg-white">
          <div className="mx-auto flex w-full max-w-[1120px] flex-wrap items-center justify-between gap-3 px-5 py-3.5 sm:px-8">
            <a href="/" aria-label="Rentora home">
              <img
                src="https://lautech-rentals.vercel.app/rentora-logo.png"
                alt="Rentora"
                className="block h-8 w-auto" />
              
            </a>
            <span className="inline-flex items-center gap-2 rounded-full border border-[#e8eaf0] bg-[#f8fafc] px-3.5 py-2 text-[13px] font-semibold text-[#0f172a]">
              <span
                className="rentora-pulse relative block h-[9px] w-[9px] rounded-full bg-[#f4b942]"
                aria-hidden="true" />
              
              Under renovation
            </span>
          </div>
        </header>

        {/* Main */}
        <main className="mx-auto flex w-full max-w-[1120px] flex-1 items-center px-5 pb-14 pt-10 sm:px-8">
          <div className="grid w-full items-center gap-10 lg:grid-cols-[1.15fr_1fr] lg:gap-16">
            {/* Left: message + notify */}
            <div className="text-center lg:text-left">
              <motion.span
                variants={fadeUp}
                initial="hidden"
                animate="show"
                custom={0}
                className="mb-6 inline-flex items-center gap-2 rounded-full bg-[#eef2ff] px-4 py-1.5 text-[13px] font-semibold text-[#2450E0]">
                
                <HardHatIcon className="h-4 w-4" aria-hidden="true" />
                Site Maintenance
              </motion.span>

              <motion.h1
                variants={fadeUp}
                initial="hidden"
                animate="show"
                custom={1}
                className="mb-5 text-[32px] font-extrabold leading-[1.15] tracking-tight text-[#0f172a] sm:text-[44px]">
                
                We're renovating your{' '}
                <span className="text-[#2450E0]">hostel search</span> experience
              </motion.h1>

              <motion.p
                variants={fadeUp}
                initial="hidden"
                animate="show"
                custom={2}
                className="mx-auto mb-9 max-w-[520px] text-[15px] leading-relaxed text-[#64748b] sm:text-[17px] lg:mx-0">
                
                Rentora is offline for scheduled upgrades — new filters, faster
                inspection booking, and a smoother way to unlock verified agents
                near LAUTECH. Back online shortly.
              </motion.p>

              <motion.div
                variants={fadeUp}
                initial="hidden"
                animate="show"
                custom={3}>
                
                {submitted ?
                <div
                  role="status"
                  className="mx-auto flex max-w-[480px] items-center justify-center gap-2.5 rounded-xl border border-[#bfe8d2] bg-[#e7f6ee] px-5 py-4 text-[15px] font-semibold text-[#147a49] lg:mx-0 lg:justify-start">
                  
                    <CheckIcon
                    className="h-[18px] w-[18px] flex-shrink-0"
                    strokeWidth={2.5} />
                  
                    You're on the list — we'll email you the moment we're back.
                  </div> :

                <form
                  onSubmit={handleSubmit}
                  noValidate
                  className="mx-auto flex max-w-[480px] flex-col gap-2.5 sm:flex-row lg:mx-0">
                  
                    <label htmlFor="email" className="sr-only">
                      Email address
                    </label>
                    <div className="relative flex-1">
                      <MailIcon
                      className="pointer-events-none absolute left-4 top-1/2 h-[18px] w-[18px] -translate-y-1/2 text-[#94a3b8]"
                      aria-hidden="true" />
                    
                      <input
                      type="email"
                      id="email"
                      name="email"
                      value={email}
                      onChange={(e) => {
                        setEmail(e.target.value);
                        if (error) setError(false);
                      }}
                      placeholder="Enter your email"
                      autoComplete="email"
                      className={`w-full rounded-xl border bg-white py-3.5 pl-11 pr-4 text-[15px] text-[#0f172a] placeholder-[#94a3b8] outline-none transition focus:border-[#2450E0] focus:ring-[3px] focus:ring-[#2450E0]/15 ${error ? 'border-[#e0402b]' : 'border-[#e2e8f0]'}`} />
                    
                    </div>
                    <button
                    type="submit"
                    className="whitespace-nowrap rounded-xl bg-[#2450E0] px-6 py-3.5 text-[15px] font-semibold text-white shadow-[0_8px_20px_-8px_rgba(36,80,224,0.5)] transition hover:bg-[#1b3ec2] active:translate-y-px">
                    
                      Notify me
                    </button>
                  </form>
                }
                {error && !submitted &&
                <p
                  className="mt-2 text-[13px] font-medium text-[#e0402b]"
                  role="alert">
                  
                    Please enter a valid email address.
                  </p>
                }
              </motion.div>
            </div>

            {/* Right: work-order card */}
            <motion.section
              variants={fadeUp}
              initial="hidden"
              animate="show"
              custom={2}
              role="region"
              aria-label="Renovation progress"
              className="relative rounded-2xl border border-[#e8eaf0] bg-white p-6 shadow-[0_16px_40px_-24px_rgba(15,30,70,0.16)] sm:p-7">
              
              {/* corner tape accent */}
              <div
                aria-hidden="true"
                className="rentora-caution absolute -top-[7px] left-8 h-3.5 w-24 -rotate-2 rounded-sm opacity-80 shadow-sm" />
              

              <div className="mb-6 flex items-center justify-between">
                <div>
                  <p className="text-[11px] font-bold uppercase tracking-[0.14em] text-[#94a3b8]">
                    Work order
                  </p>
                  <p className="text-sm font-bold text-[#0f172a]">
                    Renovation in progress
                  </p>
                </div>
                <span className="text-2xl font-extrabold text-[#2450E0]">
                  62%
                </span>
              </div>

              <div
                role="progressbar"
                aria-valuenow={62}
                aria-valuemin={0}
                aria-valuemax={100}
                aria-label="Renovation in progress"
                className="mb-7 h-2.5 overflow-hidden rounded-full bg-[#eef1f7]">
                
                <motion.div
                  initial={{
                    width: 0
                  }}
                  animate={{
                    width: '62%'
                  }}
                  transition={{
                    delay: 0.4,
                    duration: 1,
                    ease: [0.21, 0.61, 0.35, 1]
                  }}
                  className="rentora-progress-fill relative h-full overflow-hidden rounded-full bg-[#2450E0]" />
                
              </div>

              {/* Vertical timeline */}
              <ol className="space-y-1">
                {steps.map((step, i) => {
                  const isDone = step.state === 'done';
                  const isActive = step.state === 'active';
                  const Icon = step.icon;
                  return (
                    <motion.li
                      key={step.num}
                      variants={fadeUp}
                      initial="hidden"
                      animate="show"
                      custom={4 + i}
                      className={`relative flex gap-4 rounded-xl p-3.5 ${isActive ? 'border border-[#c9d5ff] bg-[#eef2ff]' : ''}`}>
                      
                      {/* connector line */}
                      {i < steps.length - 1 &&
                      <span
                        aria-hidden="true"
                        className="absolute left-[33px] top-[52px] h-[calc(100%-40px)] w-px bg-[#e8eaf0]" />

                      }
                      <span
                        className={`flex h-10 w-10 flex-shrink-0 items-center justify-center rounded-xl ${isDone ? 'bg-[#e7f6ee] text-[#1a9e5f]' : isActive ? 'bg-[#2450E0] text-white' : 'bg-[#f1f5f9] text-[#94a3b8]'}`}>
                        
                        {isDone ?
                        <CircleCheckIcon
                          className="h-5 w-5"
                          aria-hidden="true" /> :


                        <Icon
                          className={`h-5 w-5 ${isActive ? 'animate-pulse' : ''}`}
                          aria-hidden="true" />

                        }
                      </span>
                      <div className="min-w-0 pt-0.5">
                        <div className="flex items-center gap-2">
                          <span
                            className={`text-[11px] font-bold ${isDone ? 'text-[#1a9e5f]' : isActive ? 'text-[#2450E0]' : 'text-[#94a3b8]'}`}>
                            
                            {step.num}
                          </span>
                          <span className="truncate text-sm font-semibold text-[#0f172a]">
                            {step.title}
                          </span>
                          {isActive &&
                          <Loader2Icon
                            className="h-3.5 w-3.5 flex-shrink-0 animate-spin text-[#2450E0]"
                            aria-hidden="true" />

                          }
                        </div>
                        <p className="text-[13px] text-[#64748b]">
                          {step.desc}
                        </p>
                      </div>
                    </motion.li>);

                })}
              </ol>
            </motion.section>
          </div>
        </main>

        {/* Footer */}
        <footer className="border-t border-[#e8eaf0] bg-white px-5 py-6 text-center text-sm text-[#64748b]">
          Rentora · Student Housing Platform, Ogbomosho
          <a
            href="mailto:hello@rentora.ng"
            className="ml-1.5 font-semibold text-[#2450E0] hover:underline">
            
            Contact us
          </a>
        </footer>
      </div>
    </div>);

}